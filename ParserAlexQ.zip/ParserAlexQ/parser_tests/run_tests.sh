#!/bin/sh
# Alexander Quigley - CSC-4510
# Parser Phase: run sample and custom Lille syntax tests.
set -eu
cd "$(dirname "$0")/.."
make >/dev/null

failures=0
for source in program1 program2 program3 program4 program5 program6 program7 program8 program9 parser_tests/valid_*.lille; do
    output=$(./compiler "$source" 2>&1)
    if printf '%s' "$output" | grep -q '0 errors found'; then
        echo "PASS valid: $source"
    else
        echo "FAIL valid: $source -- $output"
        failures=$((failures + 1))
    fi
done
for source in parser_tests/invalid_*.lille; do
    output=$(./compiler "$source" 2>&1)
    if printf '%s' "$output" | grep -q '1 errors found' && \
       printf '%s' "$output" | grep -q 'ERROR:'; then
        echo "PASS invalid: $source"
    else
        echo "FAIL invalid: $source -- $output"
        failures=$((failures + 1))
    fi
done
printf 'Failures: %s\n' "$failures"
[ "$failures" -eq 0 ]
