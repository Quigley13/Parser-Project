# CSC-4510 Parser Phase

This project uses the Scanner Phase code and adds a recursive-descent parser for Lille syntax.

## What changed

- `parser.h` and `parser.cpp`: parse programs, declarations, statements, and expressions.
- `compiler.cpp`: runs the parser after setting up the scanner.
- `makefile`: builds and links the parser.
- `scanner.cpp`: same scanner logic from the previous phase; required file header added.
- `parser_tests/`: valid and invalid Lille programs and a test script.

## Build and run

Open Terminal in the `ScannerProj` folder:

```sh
make clean
make
./compiler parser_tests/valid_features.lille
./compiler parser_tests/invalid_missing_semicolon.lille
sh parser_tests/run_tests.sh
```

Valid input should show `0 errors found`. Invalid input should show a syntax error, its line and position, and `1 errors found`.

## How the parser works

Each main grammar rule has a function. `program()` starts parsing and calls `block()`, which checks declarations and statements. The functions use the scanner's `have()` and `must_be()` to check tokens.

`starts_statement()` describes the FIRST set for a statement. `statement_list()` repeats as long as the next token can start another statement. Tokens such as `END`, `ELSE`, and `ELSIF` let the enclosing rule finish the list (FOLLOW). After `RETURN`, an expression is optional; a semicolon means the optional part is empty.

This phase checks syntax only. Type checking, name matching, and advanced recovery belong to later phases.
