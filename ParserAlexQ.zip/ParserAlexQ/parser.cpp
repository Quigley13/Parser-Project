/*
 * Alexander Quigley - CSC-4510
 * Parser for Lille syntax using recursive descent.
 */
#include "parser.h"

// Stop after the first syntax error.
namespace { struct stop_parsing {}; }

parser::parser(scanner* input_scanner, error_handler* error_output)
    : scan(input_scanner), errors(error_output) {}

bool parser::have(sym wanted) {
    return scan->have(wanted);
}
//7
void parser::fail(int error_code) {
    errors->flag(scan->this_token(), error_code);
    throw stop_parsing{};
}

void parser::expect(sym wanted, int error_code) {
    if (!have(wanted)) fail(error_code);
    scan->must_be(wanted);
}

// Tokens that can start an expression (FIRST set).
bool parser::starts_expression() {
    return have(sym::identifier) || have(sym::integer) || have(sym::real_num) ||
        have(sym::strng) || have(sym::true_sym) || have(sym::false_sym) ||
        have(sym::left_paren_sym) || have(sym::plus_sym) ||
        have(sym::minus_sym) || have(sym::not_sym) || have(sym::odd_sym) ||
        have(sym::eof_sym);
}
//4
// Tokens that can start a statement (FIRST set).
bool parser::starts_statement() {
    return have(sym::identifier) || have(sym::exit_sym) || have(sym::return_sym) ||
        have(sym::read_sym) || have(sym::write_sym) || have(sym::writeln_sym) ||
        have(sym::null_sym) || have(sym::if_sym) || have(sym::loop_sym) ||
        have(sym::for_sym) || have(sym::while_sym);
}

bool parser::starts_declaration() {
    return have(sym::identifier) || have(sym::procedure_sym) || have(sym::function_sym);
}
 // 1
void parser::parse() {
    try {
        scan->get_token();
        program();
        if (!have(sym::end_of_program)) fail(77);
    } catch (const stop_parsing&) {
    }
}
// 2
void parser::program() {
    expect(sym::program_sym, 47);
    expect(sym::identifier, 0);
    expect(sym::is_sym, 39);
    block();
    expect(sym::semicolon_sym, 5);
}
// 3
void parser::block() {
    while (starts_declaration()) declaration();
    expect(sym::begin_sym, 78);
    statement_list();
    expect(sym::end_sym, 30);
    if (have(sym::identifier)) expect(sym::identifier, 0);
}

void parser::declaration() {
    if (have(sym::identifier)) {
        identifier_list();
        expect(sym::colon_sym, 6);
        if (have(sym::constant_sym)) expect(sym::constant_sym, 27);
        type();
        if (have(sym::becomes_sym)) {
            expect(sym::becomes_sym, 23);
            if (have(sym::integer) || have(sym::real_num) || have(sym::strng) ||
                have(sym::true_sym) || have(sym::false_sym)) {
                scan->get_token();
            } else fail(112);
        }
        expect(sym::semicolon_sym, 5);
    } else if (have(sym::procedure_sym)) {
        expect(sym::procedure_sym, 46);
        expect(sym::identifier, 0);
        if (have(sym::left_paren_sym)) {
            expect(sym::left_paren_sym, 20);
            parameter_list();
            expect(sym::right_paren_sym, 21);
        }
        expect(sym::is_sym, 39);
        block();
        expect(sym::semicolon_sym, 5);
    } else if (have(sym::function_sym)) {
        expect(sym::function_sym, 35);
        expect(sym::identifier, 0);
        if (have(sym::left_paren_sym)) {
            expect(sym::left_paren_sym, 20);
            parameter_list();
            expect(sym::right_paren_sym, 21);
        }
        expect(sym::return_sym, 51);
        type();
        expect(sym::is_sym, 39);
        block();
        expect(sym::semicolon_sym, 5);
    } else fail(106);
}

void parser::type() {
    if (have(sym::integer_sym) || have(sym::real_sym) ||
        have(sym::string_sym) || have(sym::boolean_sym)) scan->get_token();
    else fail(96);
}

void parser::identifier_list() {
    expect(sym::identifier, 0);
    while (have(sym::comma_sym)) {
        expect(sym::comma_sym, 7);
        expect(sym::identifier, 0);
    }
}

void parser::parameter_list() {
    parameter();
    while (have(sym::semicolon_sym)) {
        expect(sym::semicolon_sym, 5);
        parameter();
    }
}

void parser::parameter() {
    identifier_list();
    expect(sym::colon_sym, 6);
    if (have(sym::value_sym) || have(sym::ref_sym)) scan->get_token();
    else fail(94);
    type();
}
// 5
// END, ELSE, and ELSIF can follow a statement list.
void parser::statement_list() {
    if (!starts_statement()) fail(80);
    do {
        statement();
        expect(sym::semicolon_sym, 5);
    } while (starts_statement());
}

void parser::statement() {
    if (have(sym::if_sym)) if_statement();
    else if (have(sym::loop_sym)) loop_statement();
    else if (have(sym::for_sym)) for_statement();
    else if (have(sym::while_sym)) while_statement();
    else simple_statement();
}

void parser::simple_statement() {
    if (have(sym::identifier)) {
        expect(sym::identifier, 0);
        if (have(sym::becomes_sym)) {
            expect(sym::becomes_sym, 23);
            expression();
        } else if (have(sym::left_paren_sym)) {
            expect(sym::left_paren_sym, 20);
            expression_list();
            expect(sym::right_paren_sym, 21);
        }
    } else if (have(sym::exit_sym)) {
        expect(sym::exit_sym, 32);
        if (have(sym::when_sym)) {
            expect(sym::when_sym, 57);
            expression();
        }
        //6
    } else if (have(sym::return_sym)) {
        expect(sym::return_sym, 51);
        if (starts_expression()) expression(); // The value after RETURN is optional.
    } else if (have(sym::read_sym)) {
        expect(sym::read_sym, 48);
        bool has_parens = have(sym::left_paren_sym);
        if (has_parens) expect(sym::left_paren_sym, 20);
        identifier_list();
        if (has_parens) expect(sym::right_paren_sym, 21);
    } else if (have(sym::write_sym) || have(sym::writeln_sym)) {
        bool newline = have(sym::writeln_sym);
        if (newline) expect(sym::writeln_sym, 59);
        else expect(sym::write_sym, 58);
        bool has_parens = have(sym::left_paren_sym);
        if (has_parens) expect(sym::left_paren_sym, 20);
        if (newline) {
            if (starts_expression()) expression_list();
        } else expression_list();
        if (has_parens) expect(sym::right_paren_sym, 21);
    } else if (have(sym::null_sym)) {
        expect(sym::null_sym, 42);
    } else fail(83);
}

void parser::if_statement() {
    expect(sym::if_sym, 36);
    expression();
    expect(sym::then_sym, 54);
    statement_list();
    while (have(sym::elsif_sym)) {
        expect(sym::elsif_sym, 29);
        expression();
        expect(sym::then_sym, 54);
        statement_list();
    }
    if (have(sym::else_sym)) {
        expect(sym::else_sym, 28);
        statement_list();
    }
    expect(sym::end_sym, 30);
    expect(sym::if_sym, 36);
}

void parser::loop_statement() {
    expect(sym::loop_sym, 40);
    statement_list();
    expect(sym::end_sym, 30);
    expect(sym::loop_sym, 40);
}

void parser::for_statement() {
    expect(sym::for_sym, 34);
    expect(sym::identifier, 0);
    expect(sym::in_sym, 37);
    if (have(sym::reverse_sym)) expect(sym::reverse_sym, 52);
    range();
    loop_statement();
}

void parser::while_statement() {
    expect(sym::while_sym, 57);
    expression();
    loop_statement();
}

void parser::expression_list() {
    expression();
    while (have(sym::comma_sym)) {
        expect(sym::comma_sym, 7);
        expression();
    }
}

void parser::range() {
    simple_expression();
    expect(sym::range_sym, 22);
    simple_expression();
}

void parser::expression() {
    simple_expression();
    if (have(sym::less_than_sym) || have(sym::greater_than_sym) ||
        have(sym::equals_sym) || have(sym::not_equals_sym) ||
        have(sym::less_or_equal_sym) || have(sym::greater_or_equal_sym)) {
        scan->get_token();
        simple_expression();
    } else if (have(sym::in_sym)) {
        expect(sym::in_sym, 37);
        range();
    }
}

void parser::simple_expression() {
    expression2();
    while (have(sym::ampersand_sym)) {
        expect(sym::ampersand_sym, 19);
        expression2();
    }
}

void parser::expression2() {
    term();
    while (have(sym::plus_sym) || have(sym::minus_sym) || have(sym::or_sym)) {
        scan->get_token();
        term();
    }
}

void parser::term() {
    factor();
    while (have(sym::asterisk_sym) || have(sym::slash_sym) || have(sym::and_sym)) {
        scan->get_token();
        factor();
    }
}

void parser::factor() {
    if (have(sym::plus_sym) || have(sym::minus_sym)) {
        scan->get_token();
        primary();
    } else {
        primary();
        if (have(sym::power_sym)) {
            expect(sym::power_sym, 18);
            primary();
        }
    }
}

void parser::primary() {
    if (have(sym::not_sym) || have(sym::odd_sym)) {
        scan->get_token();
        expression();
    } else if (have(sym::left_paren_sym)) {
        expect(sym::left_paren_sym, 20);
        simple_expression();
        expect(sym::right_paren_sym, 21);
    } else if (have(sym::identifier)) {
        expect(sym::identifier, 0);
        if (have(sym::left_paren_sym)) {
            expect(sym::left_paren_sym, 20);
            expression_list();
            expect(sym::right_paren_sym, 21);
        }
    } else if (have(sym::integer) || have(sym::real_num) || have(sym::strng) ||
               have(sym::true_sym) || have(sym::false_sym) || have(sym::eof_sym)) {
        scan->get_token();
    } else fail(92);
}
