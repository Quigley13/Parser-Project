/* Alexander Quigley - CSC-4510
 * Lille parser declarations.
 */
#ifndef PARSER_H_
#define PARSER_H_

#include "scanner.h"
#include "error_handler.h"

class parser {
private:
    scanner* scan;
    error_handler* errors;

    using sym = symbol::symbol_type;

    bool have(sym wanted);
    void expect(sym wanted, int error_code);
    void fail(int error_code);
    bool starts_expression();
    bool starts_statement();
    bool starts_declaration();

    void program();
    void block();
    void declaration();
    void type();
    void parameter_list();
    void parameter();
    void identifier_list();
    void statement_list();
    void statement();
    void simple_statement();
    void if_statement();
    void loop_statement();
    void for_statement();
    void while_statement();
    void expression_list();
    void range();
    void expression();
    void simple_expression();
    void expression2();
    void term();
    void factor();
    void primary();

public:
    parser(scanner* input_scanner, error_handler* error_output);
    void parse();
};

#endif
